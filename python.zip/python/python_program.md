### Table of Contents

|  No.  | Questions                                                                                                |
| :---: | -------------------------------------------------------------------------------------------------------- |
|   1   | [swap two variables](#swap-two-variables)                                                                |
|   2   | [check if a number is Even or odd](#program-to-check-if-a-number-is-even-or-odd)                         |
|       | [To Check if a String is a Palindrome](#To-Check-if-a-String-is-a-Palindrome)                            |
|       | [To Check if a Number is a Palindrome](#To-Check-if-a-Number-is-a-Palindrome)                            |
|       | [Find the Factorial of a Number](#Find-the-Factorial-of-a-Number)                                        |
|       | [find Fibonacci series up to n](#find-Fibonacci-series-up-to-n)                                          |
|       | [check if the number is an Armstrong number or not](#check-if-the-number-is-an-Armstrong-number-or-not)  |
|       | [generate a random number between 0 and 9](#Program-to-generate-a-random-number-between-0-and-9)         |
|       | [Get a Substring of a String](#Get-a-Substring-of-a-String)                                              |
|       | [How to reverse a sentence in Python input by User?](#How-to-reverse-a-sentence-in-Python-input-by-User) |
|       | [Count number of characters in a string](#count-number-of-characters-in-a-string)                        |
|       | [convert a list to string](#program-to-convert-a-list-to-string)                                         |


### **Ques. swap two variables?**
1. Using a temporary variable
```python
a = 11
b = 7

temp = a
a = b
b = temp

print(a) # 7
print(b) # 11
```
2. Without a temporary variable
```python
a = 11
b = 7

a, b = b, a

print(a) # 7
print(b) # 11
```
3. Using arithmetic operators
```python
a = 11
b = 7

a = a + b # a = 18, b = 7
b = a - b # a = 18, b = 11
a = a - b # a = 7,  b = 11

print(a) # 7
print(b) # 11
```
4. Using multiplication and division operator
```python
P = int( input("Please enter value for P: "))  
Q = int( input("Please enter value for Q: "))  
   
# To Swap the values of two variables using Addition and subtraction operator  
P = P * Q    
Q = P / Q   
P = P / Q  
   
print ("The Value of P after swapping: ", P)  
print ("The Value of Q after swapping: ", Q)

# XOR swap
P = P ^ Q    
Q = P ^ Q   
P = P ^ Q  
   
print ("The Value of P after swapping: ", P)  
print ("The Value of Q after swapping: ", Q)
```

### **Ques. Program to check if a number is Even or odd?**
```python
# 1 Option
num = int(input("Enter a number: "))
if (num % 2) == 0:
   print("{0} is Even".format(num))
else:
   print("{0} is Odd".format(num))

# 2 option
def evenOrOdd(n):
    if n%2 == 0:
        print('even Number hai')
    else:
        print('Odd Number hai')
evenOrOdd(6)
```

### **Ques. To Check if a String is a Palindrome**
```python
def isPalindrome(string):
    rev = string[::-1]
    # rev = ''.join(reversed(s))    # 2nd Option to reversed string
    if(rev == string):
        print("The string is a palindrome!");
    else:
        print("The string isn't a palindrome!");

s = "malayalam"
isPalindrome(s)

Output:- The string is a palindrome!
=========================================================
x = "malayalam"
 
w = ""
for i in x:
    w = i + w 
if (x == w):
    print("Yes")
else:
    print("No")

Output:- Yes
```

### **Ques. To Check if a Number is a Palindrome**
```python
num = int(input("Enter a number:"))
temp = num
reverse = 0
while temp > 0:
    remainder = temp%10
    reverse = (reverse*10)+remainder
    temp = temp//10
if num == reverse:
  print('Palindrome')
else:
  print("Not Palindrome")
```

### **Ques. Check Prime Number Or Not?**
```python
num = int(input("Enter a number: "))
if num > 1:
   for i in range(2,num):
       if (num % i) == 0:
           print(num,"is not a prime number")
           break
   else:
       print(num,"is a prime number")
       
else:
   print(num,"is not a prime number")

Output:- 3
3 is a prime number
```

### **Ques. Prime Number Print between lower to upper**
```python
lower = int(input(" Please Enter the Minimum Value: "))
upper = int(input(" Please Enter the Maximum Value: "))

print("Prime numbers between", lower, "and", upper, "are:")

for num in range(lower, upper + 1):
   # all prime numbers are greater than 1
   if num > 1:
       for i in range(2, num):
           if (num % i) == 0:
               break
       else:
           print(num)

Output:- 
11
13
17
19
```

### **Ques. Find the Factorial of a Number?**
* factorial of 6 is 6*5*4*3*2*1 which is 720.
```python
num = int(input("Enter a number: "))    
factorial = 1    
if num < 0:    
   print(" Factorial does not exist for negative numbers")    
elif num == 0:    
   print("The factorial of 0 is 1")    
else:    
   for i in range(1,num + 1):    
       factorial = factorial*i    
   print("The factorial of",num,"is",factorial) 

Output:- 
Enter a number: 6
The factorial of 6 is 720
```

### **Ques. Find Fibonacci series up to n**
```python
def fibonacci(n):
    first = 0
    second = 1
    if n < 0:
        print("Incorrect input")
    elif n == 0:
        return 0
    elif n == 1:
        return second
    else:
        print(first)
        print(second)
        for i in range(2, n):
            third = first + second
            first = second
            second = third
            print(third)

fibonacci(9)

Output:- 0 1 1 2 3 5 8 13 21
```
* Using While Loop
```python
def fibonacci(n):
    first = 0
    second = 1
    count = 0
    if n < 0:
        print("Incorrect input")
    elif n == 0:
        return 0
    elif n == 1:
        return second
    else:
        while count < n:
            print(first)  
            third = first + second  
           # At last, we will update values  
            first = second  
            second = third  
            count += 1
fibonacci(9)
```

### **Ques. Reverse a Number**
```python
# using a while loop
Number = int(input("Please Enter any Number: "))
Reverse = 0
while(Number > 0):
    Reminder = Number %10
    Reverse = (Reverse *10) + Reminder
    Number = Number //10

print("Reverse of entered number is = %d" %Reverse)

Output:-
Please Enter any Number: 68765
Reverse of entered number is = 56786

# Using String slicing
num = 9412
print(str(num)[::-1])

Output:-
num = 2149

# Using Recursion
num = int(input("Enter the number: "))  
revr_num = 0    # initial value is 0. It will hold the reversed number  
def recur_reverse(num):  
    global revr_num   # We can use it out of the function  
    if (num > 0):  
        Reminder = num % 10  
        revr_num = (revr_num * 10) + Reminder  
        recur_reverse(num // 10)  
    return revr_num  
  
  
revr_num = recur_reverse(num)  
print("Reverse of entered number is = %d" % revr_num)

Output:- 
Enter the number: 1284
Reverse of entered number is = 4821
```

### **Ques. Check if the number is an Armstrong number or not?**
* 153 = 1*1*1 + 5*5*5 + 3*3*3 = 153
* 1634 = 1*1*1*1 + 6*6*6*6 + 3*3*3*3 + 4*4*4*4 = 1634
```python
num = int(input("Enter a number: "))
len = len(str(num))
sum = 0
temp = num

while temp > 0:
   digit = temp % 10
   sum = sum + digit ** len
   temp = temp//10

if num == sum:
   print(num,"is an Armstrong number")
else:
   print(num,"is not an Armstrong number")

Output:- 
Enter a number: 1634
1634 is an Armstrong number
```




### **Ques. program to convert a list to string**
```python
def listToString(s):
    blank =""
    for element in s:
        blank = blank + ' ' + element
    print(blank)

s = ['Hello', 'mohit', 'saxena']
listToString(s)

Output:- Hellomohitsaxena
```
* Using list comprehension 
```python
s = ['I', 'want', 4, 'apples', 'and', 18, 'bananas']
listToStr = ' '.join([str(elem) for elem in s])
print(listToStr)

Output:- I want 4 apples and 18 bananas
```
* Using .join() method 
```python
def listToString(s):
    str1 = " "
    return (str1.join(s))
    
s = ['Hello', 'Mohit', 'Saxena']
print(listToString(s))

Output:- Hello Mohit Saxena
```
* Using map()
```python
s = ['I', 'want', 4, 'apples', 'and', 18, 'bananas']
listToStr = ' '.join(map(str, s))
print(listToStr)
```


### Program to generate a random number between 0 and 9?
```python
import random
print(random.randint(0,9))

Output:- 0 se 9 tak ka koi bhi number aa sakta hai.
```



### **Ques. How to reverse a sentence in Python input by User?**
```python
inputsentence = input("Please input  a sentence : ")
splitString = inputsentence.split()      # ['i', 'love', 'Mohit', 'Saxena']
reversedString = reversed(splitString)
print(" ".join(reversedString))

Output:- i love Mohit Saxena
Saxena Mohit love i
```
* 2 option
```python
my_str = input("Please enter your own String : ")
str = ''
for i in my_str:
    str = i + str
print("\nThe Original String is: ", my_str)
print("The Reversed String is: ", str)

Output:-
The Original String is:  i love Mohit Saxena
The Reversed String is:  anexaS tihoM evol i
```


### **Ques. Multiply two numbers without using arithmetic operator?**
```python
num1=int(input("Enter a number for num1: "))
num2=int(input("Enter a number for num2: "))
product=0
for i in range (1,num2+1):  #Python for loop
 product=product+num1       #product+=num1
print("Multiplication of numbers: ",product)

Output:- 
Enter a number for num1: 4
Enter a number for num2: 4
Multiplication of numbers:  16
```

### String Pattern
```python
# Program 1:-

def pypart(n):
    for i in range(0, n):
        for j in range(0, i+1):
            print("* ",end="")
        print()
n = 5
pypart(n)

Output:-
* 
* * 
* * * 
* * * * 
* * * * * 
====================================================================

str1 = input("enter the string: ")
len = len(str1)
for i in range(len):
    for j in range(i+1):
        print(str1[i], end="")
    print()

Output:-
enter the string: Mohit
M
oo
hhh
iiii
ttttt
========================================================================
str1 = input("enter the string: ")
len = len(str1)
for i in range(len):
    for j in range(i+1):
        print(str1[j], end="")
    print()

Output:-
enter the string: mohit
m
mo
moh
mohi
mohit
```

### Python program to convert a list to string
```python
def listToString(s):
    blank =""
    for element in s:
        blank = blank + ' ' + element
    print(blank)

s = ['Hello', 'mohit', 'saxena']
listToString(s)

Output:- Hellomohitsaxena
------------------------------------------------------------------

# Using list comprehension 
s = ['I', 'want', 4, 'apples', 'and', 18, 'bananas']
listToStr = ' '.join([str(elem) for elem in s])
print(listToStr)

Output:- I want 4 apples and 18 bananas
----------------------------------------------------------------

# Using .join() method 
def listToString(s):
    str1 = " "
    return (str1.join(s))
    
s = ['Hello', 'Mohit', 'Saxena']
print(listToString(s))

Output:- Hello Mohit Saxena
----------------------------------------------------------------

# Using map()
s = ['I', 'want', 4, 'apples', 'and', 18, 'bananas']
listToStr = ' '.join(map(str, s))
print(listToStr)
```


https://prepinsta.com/python-program/find-a-number-is-palindrome-or-not/