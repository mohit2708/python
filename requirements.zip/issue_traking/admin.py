from django.contrib import admin
from issue_traking.models import Ticket

# Register your models here.
admin.site.register(Ticket)
