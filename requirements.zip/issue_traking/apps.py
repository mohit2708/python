from django.apps import AppConfig


class IssueTrakingConfig(AppConfig):
    name = 'issue_traking'
