from django.contrib import admin
#from auth_app.models import UserProfile

# Register your models here.
#admin.site.register(UserProfile)