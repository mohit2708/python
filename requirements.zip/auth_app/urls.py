from django.contrib import admin
from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    #path('admin/', admin.site.urls),
    path('', views.signup),
    path('signup/', views.signup, name="signup"),    
    path('login/', views.do_login, name="login"), 
    #path("logout", auth_views.LogoutView.as_view(), name="logout"),
    path('logout/', views.do_logout, name="logout"), 
    path('home/', views.home, name="home"),   
]
