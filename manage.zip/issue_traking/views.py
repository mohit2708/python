from django.shortcuts import render, redirect
from . import forms
from issue_traking.forms import TicketForm
# Create your views here.

def index(request):

    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect('/issuses')
            except:
                pass
    else:
        form = TicketForm()
    return render(request, 'index.html', {'form':form})














