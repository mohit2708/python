from django.shortcuts import render
from django.http import HttpResponse
from ecomm.models import Product
from math import ceil

# Create your views here.
def index(request):
    products = Product.objects.all()
    #print(products)
    n = len(products)
    nslide = n//4 + ceil((n/4)-(n//4))
    params = {'no_of_slides':nslide, 'range':range(1, nslide), 'product':products}
    return render(request, 'ecomm/index.html', params)

