from django.contrib import admin
from ecomm.models import Product
# Register your models here.

admin.site.register(Product)   

