from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
# Create your views here.

def home(request):
	# return HttpResponse("Hello I am home Page")
	return render(request, "index.html")

def signup(request):

	if request.method == 'POST':

		first_name = request.POST['fname']
		last_name = request.POST['lname']
		username = request.POST['username']
		email = request.POST['email']
		password = request.POST['password']
		cpassword = request.POST['cpassword']

		if password == cpassword:
			if User.objects.filter(username=username).exists():
				print('user name is alreat taken')
				messages.info(request,'user name is alreat taken')
				return redirect('signup')
			elif User.objects.filter(email=email).exists():
				print('email is alreat taken')
				messages.info(request,'email is alreat taken')
				return redirect('signup')
			else:
				myuser = User.objects.create_user(username=username,email=email,password=password,first_name=first_name,last_name=last_name)
				myuser.save()
				messages.success(request,'Your acoount has been succesfully created.')
				return redirect('signin')
		else:
			print('password is not match')
			messages.info(request,'password is not match')
			return redirect('signup')


		## 2 Option to insert the data
		#####################################
		# user  = User(
		# 	first_name = request.POST['fname'],
		# 	last_name = request.POST['lname'],
		# 	username = request.POST['username'],
		# 	email = request.POST['email'],
		# 	password = request.POST['password'],
		# )
		# user.set_password(user.password)
		# user.save()
		# messages.success(request,'Your acoount has been succesfully created.')
		# messages.success(request,'Your acoount has been succesfully created.')
		# return redirect('signin')
		#######################################


	else:
		return render(request, "authentication/signup.html")

def signin(request):
	if request.method == 'POST':
		username = request.POST['username']
		password = request.POST['password']

		user = auth.authenticate(username=username, password=password)

		if user is not None:
			auth.login(request,user)
			return redirect('home')
		else:
			messages.info(request,'invalid creediantiial')
			return redirect('signin')

		# user = authenticate(username=username, password=password)

		# if user is not None:
		# 	login(request, user)
		# 	fname = user.first_name
		# 	return render(request, "index.html", {'fname':fname})
		# else:
		# 	messages.error(request, "Bad creediantiial")
		# 	return redirect('home')
		
	else:
		return render(request, "authentication/signin.html")

def logout(request):
    print('logged out')
    auth.logout(request)

    return redirect('home')
