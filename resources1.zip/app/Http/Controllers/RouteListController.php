<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\RouteOperation;
use App\Connection;
use DB;
use App\DeviceInfo;

class RouteListController extends Controller
{
    public function index(Request $request)
    {	

      $showdeviceinfo = DeviceInfo::all();        
      $q = $request->get('q');

        
        $roulelists = DB::table('tbl_route_tables_info as routeinfo')
       ->select('routeinfo.*','operationroute.*','deviceinfo.device_serial','deviceinfo.tunnel_ip','deviceinfo.id as deviceinfo_id')
       ->join('tbl_device_info as deviceinfo', 'deviceinfo.id', '=','routeinfo.map_device_key')
        ->join('tbl_operation_on_route as operationroute', 'operationroute.ip_address', '=','routeinfo.destination')
           ->orwhere('deviceinfo.device_serial','LIKE','%'.$q.'%')
           ->groupBy('operationroute.ip_address')
           ->get();  
           //dd($roulelists);
           //->paginate(2);       
      return view('route_list', compact('roulelists','showdeviceinfo')); 


         
	}

}