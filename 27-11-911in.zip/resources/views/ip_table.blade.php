@extends('layouts.app')
@section('content')
<div class="main-content">
   <div class="section__content section__content--p30">
      <div class="container-fluid">
         <div class="row m-t-30">
            <div class="col-lg-12">
               <h3 class="title-5 m-b-35">IP Table</h3>
               <div class="table-responsive m-b-40">
                  <div class="table-title">
                     <div class="row">
                        <div class="col-sm-6">
                           <!-- <form class="form-inline my-2 my-lg-0" action="{{url('route-list')}}" method="GET">
                              <input class="form-control" type="search" name="q" placeholder="Device Serial Number"> &nbsp;
                              <button type="submit" class="btn btn-primary">Search</button>
                           </form> -->
                           <br> 
                        </div>
                        <div class="col-sm-3">
                        </div>
                        <div class="col-sm-3">
                           <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="fa fa-plus"></i> <span>Add New Rule</span></a>  
                           <!-- <a href="javascript:void(0)" class="btn btn-success" id="new-customer" data-toggle="modal"><i class="fa fa-plus"></i> <span>Add New Route</span></a> -->
                        </div>
                     </div>
                  </div>
                  <br>
                  <table class="table table-borderless table-data3">
                     <thead>
                        <tr>
                           <th>Device Serial Number</th>
                           <th>Chain Type</th>
                           <th>Pakets</th>
                           <th>Bytes</th>
                           <th>Target</th>
                           <th>Protocol</th>
                           <th>In Interface</th>
                           <th>Out Interface</th>
                           <th>Source Address</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                        </tr>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Add Moduel -->
                <div id="addEmployeeModal" class="modal fade">
   <div class="modal-dialog">
      <div class="modal-content">
         <form action ="{{url('route-opertion/store')}}" method="POST">
            {!! csrf_field() !!}
            <div class="modal-header">
               <h4 class="modal-title">Add New Route</h4>
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                  <label>Add Rule</label>
                  <select class="form-control @error('network') is-invalid @enderror" id="frules" name="frules" onchange="ShowHideDiv(this);">
                     <option value="" disabled selected>-- Select Your Rule --</option>
                     <option value="IN-F">InComing Traffic</option>
                     <option value="OUT-F">OutGoing Traffic</option>
                     <option value="FOR-F">Forword Traffic</option>
                     <option value="PRE-NAT">Pre Routing Using Net Table</option>
                     <option value="POST-NAT">Post Routing Using Net Table</option>
                     <option value="IN-NAT">Incoming Rule For Net Table</option>
                     <option value="OUT-NAT">Outcoming Rule For Net Table</option>
                  </select>                  
               </div>   
              <!--  <div class="form-group">
                    <label>Device Serial Number</label>
                    <select class="form-control @error('network') is-invalid @enderror" id="device_serial_number" name="device_serial_number">
                        <option value="" disabled selected>-- Select Serial Number --</option>
                    </select>                
               </div> -->
               <div class="form-group" id="sin_interface" style="display: none;">
                    <label>In Interface</label>
                    <select class="form-control @error('network') is-invalid @enderror" id="in_interface" name="in_interface">
                        <option value="" disabled selected>-- Select Interface --</option>
                        <option value="LTE">LTE</option>
                        <option value="WAN">WAN</option>
                        <option value="LAN">LAN</option>
                    </select>                
               </div> 
               <div class="form-group" id="sout_interface" style="display: none;">
                    <label>Out Interface</label>
                    <select class="form-control @error('network') is-invalid @enderror" id="out_interface" name="out_interface">
                        <option value="" disabled selected>-- Select Interface --</option>
                        <option value="LTE">LTE</option>
                        <option value="WAN">WAN</option>
                        <option value="LAN">LAN</option>
                    </select>                
               </div>             
               <div class="form-group">
                    <label>Protocol</label>
                    <select class="form-control @error('network') is-invalid @enderror" id="protocol" name="protocol">
                        <option value="" disabled selected>-- Select Protocol --</option>
                        <option value="TCP">TCP</option>
                        <option value="UDP">UDP</option>
                        <option value="ICMP">ICMP</option>    
                    </select>                
               </div>
                <!-- <div class="form-group">
                    <label>Destination ID</label>
                    <select class="form-control @error('network') is-invalid @enderror" id="destination_id" name="destination_id">
                        <option value="" disabled selected>-- Select Destination Id --</option>
                    </select>                
               </div> -->
               <!-- <div class="form-group">
                  <label>IP Address</label>
                  <input type="text" class="form-control @error('network') is-invalid @enderror" id="ip_address" name="ip_address" placeholder="Enter Your IP Address" value="{{ old('ip_address') }}">
                 
               </div> -->
               <!-- <div class="form-group">
                  <label>NetMask</label>
                  <input type="text" class="form-control @error('netmask_value') is-invalid @enderror" id="netmask_value" name="netmask_value" placeholder="NetMask Value" value="{{ old('netmask_value') }}">
                
               </div> -->
               
               <!-- <div class="form-group">
                  <label>Network</label>
                  <select class="form-control @error('network') is-invalid @enderror" id="network" name="network">
                     <option value="" disabled selected>-- Select Network --</option>
                     <option value="LTE">LTE</option>
                     <option value="WAN">WAN</option>
                  </select>                  
               </div>
               <div class="form-group">
                  <label>Route Option</label>
                  <select class="form-control @error('route_option') is-invalid @enderror" id="route_option" name="route_option">
                     <option value="" disabled selected>-- Select Route Option --</option>
                     <option value="Add">Add</option>
                     <option value="Delete">Delete</option>
                  </select>                  
               </div>  -->                     
            </div>
            <div class="modal-footer">
               <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">         
               <button type="submit" class="btn btn-primary btn-sm">Submit</button>
            </div>
         </form>
      </div>
   </div>
</div>
<script type="text/javascript">
        function ShowHideDiv(that) {
    if (that.value == "IN-F" || that.value == "FOR-F" || that.value == "PRE-NAT" || that.value == "IN-NAT") {
        document.getElementById("sin_interface").style.display = "block";
    } else {
        document.getElementById("sin_interface").style.display = "none";
    }

    if (that.value == "OUT-F" || that.value == "FOR-F" || that.value == "POST-NAT" || that.value == "OUT-NAT") {
        document.getElementById("sout_interface").style.display = "block";
    } else {
        document.getElementById("sout_interface").style.display = "none";
    }
}
</script>
@endsection