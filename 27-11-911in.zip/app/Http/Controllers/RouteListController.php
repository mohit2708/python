<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\RouteOperation;
use App\Connection;
use DB;
use App\DeviceInfo;

class RouteListController extends Controller
{
    public function index(Request $request)
    {	     
      $showdeviceinfo = DeviceInfo::all();
      $q = $request->get('q');
        
      $roulelists = DB::table('tbl_route_tables_info as routeinfo')
      ->select('routeinfo.*','operationroute.*','deviceinfo.device_serial','deviceinfo.id as deviceinfo_id')
      ->join('tbl_device_info as deviceinfo', 'deviceinfo.id', '=','routeinfo.map_device_key')
      ->join('tbl_operation_on_route as operationroute', 'operationroute.ip_address', '=','routeinfo.destination')
         ->orwhere('deviceinfo.device_serial','LIKE','%'.$q.'%')
         ->groupBy('operationroute.ip_address')
         ->get();  
         //dd($roulelists);
         //->paginate(2);       
      return view('route_list', compact('roulelists','showdeviceinfo')); 
         
	  }
      public function getOpertianRoute(Request $request){
        $routeoperation = DB::table('tbl_route_tables_info as routeinfo')
       ->select('routeinfo.*','operationroute.*')
       ->join('tbl_operation_on_route as operationroute', 'routeinfo.destination', '=','operationroute.ip_address')
       ->where('routeinfo.destination', $request['ip_address'])
       ->get(); 
       return $routeoperation;
      }

      public function OpertionUpdate(request $request){

        $routeopration = RouteOperation::find($request->get('selectitem'));
        $routeopration->ip_address    = $request->get('ip_address1');
        $routeopration->device_serial = $request->get('device_serial_number1');
        $routeopration->network_type  = $request->get('network1');
        $routeopration->route_option  = $request->get('route_option1');
        $routeopration->netmask_value = $request->get('netmask_value1');
        dd($routeopration);
        $routeopration->update();
        
        return redirect('route-list')->with('success', 'Connection updated successfully');
      }

}