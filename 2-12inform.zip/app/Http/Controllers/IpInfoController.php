<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\IpOperation;
use App\DeviceInfo;
use App\IpRules;
use DB;

class IpInfoController extends Controller
{
    public function index(Request $request)
    {	
    	$iprules = IpRules::all();  
    	$showdeviceinfo = DeviceInfo::all(); 

    	$main_array = [];
	      foreach( $showdeviceinfo as $interfaceinf){
	        $interface_with_ip =  $interfaceinf->interface_with_ip;           
	        if($interface_with_ip !== ""){
	          $interface_with_ip1 = explode(',', $interface_with_ip);
	          foreach($interface_with_ip1 as $interface_with_ip2){
	            $interface_with_ip3 = explode('::',$interface_with_ip2);
	             $a = array(
	              'device_serial'=>  $interfaceinf->device_serial,
	              'ip'  =>  $interface_with_ip3[0],
	              'interface' => $interface_with_ip3[1]
	             );
	           $main_array [] =  $a;
	          }
	        }
	      }  
        return view('ip_table', compact('showdeviceinfo','main_array','iprules'));     
    }

    public function IPStore(Request $request){
		$this->validate($request,[
			'device_serial_number'	=> 'required',
			'frules'			=> 'required',
        ]);	

   		   $trans_desti_add = $request->trans_desti_add;
   		   $trans_desti_port = $request->trans_desti_port;
   		   $desti_add_port = $trans_desti_add.':'. $trans_desti_port;

		   $ipinfo         		  		= new IpOperation;		   
		   $ipinfo->device_serial  	  	= $request->device_serial_number;	//device Serial
		   $ipinfo->rule_type  	  		= $request->frules;					//Rules
		   $ipinfo->in_interface  		= $request->in_interface;			//In Interface
		   $ipinfo->out_interface   	= $request->out_interface;			//Out Interface 
		   $ipinfo->protocol   			= $request->protocol;				//Protocol
		   $ipinfo->orginal_desti_ip	= $request->cidestination_ip;		//orginal_desti_ip
		   $ipinfo->orginal_desti_port  = $request->odpdestination_ip;		//orginal_desti_port
		   $ipinfo->orginal_source_ip  	= $request->osidestination_ip;		//osidestination_ip
		   $ipinfo->orginal_source_port = $request->osportsource_ip;		//orginal_source_port

		   $ipinfo->rule_action   		= $request->rule_actionadr;
		   $ipinfo->rule_action   		= $request->rule_actionaccept;
		   $ipinfo->rule_action   		= $request->layout_select;
			   
		   $ipinfo->translate_desti_address  = $request->trans_desti_add;
		   $ipinfo->translate_source_address   = $desti_add_port;

		   //$ipinfo->redirect_select  	= $request->demo;

		   $ipinfo->redirect_port   	= $request->redirect_port;		   
		   //$ipinfo->masquerade_select   = $request->masquerade_port;
		   //$ipinfo->masquerade_port  	= $request->masquerade_port;			   
		   $ipinfo->add_delete   		= $request->add_delete;          
		   $ipinfo->save();
		  
		   return redirect('ip-info')->with('success', 'IP Information added successfully');
    
	}

	public function InterfaceAjax(Request $request){

		// dd($request->all());

		$showdeviceinfo = DeviceInfo::all();
		// $test = $request->device_serial_number;
		// dd($test);
		// $finterface = DB::table("tbl_device_info")
  //                   ->where("device_serial",$request->device_serial_number);
  //       return response()->json($finterface);


    	$main_array = [];
	      foreach( $showdeviceinfo as $interfaceinf){
	        $interface_with_ip =  $interfaceinf->interface_with_ip;           
	        if($interface_with_ip !== ""){
	          $interface_with_ip1 = explode(',', $interface_with_ip);
	          foreach($interface_with_ip1 as $interface_with_ip2){
	            $interface_with_ip3 = explode('::',$interface_with_ip2);
	             $a = array(
	              'device_serial'=>  $interfaceinf->device_serial,
	              'ip'  =>  $interface_with_ip3[0],
	              'interface' => $interface_with_ip3[1]
	             );
	           $main_array [] =  $a;
	          }
	        }
	      }
	      $test1 = in_array($request['device_serial'], $main_array);
	      echo '<pre>';
	      print_r(json_encode($test1));

	    // echo '<pre>';
	    // print_r($main_array);
	    return $main_array;

	}
    
}
