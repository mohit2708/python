@extends('layouts.app')
@section('content')
<div class="main-content">
   <div class="section__content section__content--p30">
      <div class="container-fluid">
         <div class="row m-t-30">
            <div class="col-lg-12">
               <h3 class="title-5 m-b-35">IP Table</h3>
               @if ($message = Session::get('success'))
               <div class="alert alert-success alert-block">
                  <button type="button" class="close" data-dismiss="alert">×</button> 
                  <strong>{{ $message }}</strong>
               </div>
               @endif
               <div class="table-responsive m-b-40">
                  <div class="table-title">
                     <div class="row">
                        <div class="col-sm-6">
                           <!-- <form class="form-inline my-2 my-lg-0" action="{{url('route-list')}}" method="GET">
                              <input class="form-control" type="search" name="q" placeholder="Device Serial Number"> &nbsp;
                              <button type="submit" class="btn btn-primary">Search</button>
                           </form> -->
                           <br> 
                        </div>
                        <div class="col-sm-3">
                        </div>
                        <div class="col-sm-3">
                           <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="fa fa-plus"></i> <span>Add New Rule</span></a>  
                           <!-- <a href="javascript:void(0)" class="btn btn-success" id="new-customer" data-toggle="modal"><i class="fa fa-plus"></i> <span>Add New Route</span></a> -->
                        </div>
                     </div>
                  </div>
                  <br>
                  <table class="table table-borderless table-data3" id="ip_tables">
                     <thead>
                        <tr>
                           <th>Device Serial Number</th>
                           <th>Chain Type</th>                           
                           <th>Target</th>
                           <th>Protocol</th>
                           <th>In Interface</th>
                           <th>Out Interface</th>
                           <th>Source Address</th>
                           <th>Destination Address</th>
                           <th>Route Details</th>                           
                        </tr>
                     </thead>
                     <tbody>
                         @foreach($iprules as $iprule)
                        <tr>
                           <td>{{$iprule->device_serial}}</td>
                           <td>{{$iprule->chain_type}}</td>                          
                           <td>{{$iprule->target}}</td>
                           <td>{{$iprule->protocol}}</td>
                           <td>{{$iprule->in_interface}}</td>
                           <td>{{$iprule->out_interface}}</td>
                           <td>{{$iprule->source_address}}</td>
                           <td>{{$iprule->destination_address}}</td>
                           <td>{{$iprule->rule_details}}</td>                           
                        </tr>
                        @endforeach
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Add Moduel -->
                <div id="addEmployeeModal" class="modal fade">
   <div class="modal-dialog">
      <div class="modal-content">
         <form action ="{{url('ip-info/store')}}" method="POST" id="fiptables">
            {!! csrf_field() !!}
            <div class="modal-header">
               <h4 class="modal-title">Add New Rule</h4>
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                                <label>Device Serial Number</label>
                                <select class="form-control @error('network') is-invalid @enderror" id="device_serial_number" name="device_serial_number">
                                   <option value="" selected>-- Select Device Number --</option>
                                   @foreach($showdeviceinfo as $dinfo)
                                   <option value="{{$dinfo->device_serial}}">{{$dinfo->device_serial}}</option>
                                   @endforeach  
                                </select>
                                @error('device_serial_number')
                                <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                        </div>
                    </div>
                   <div class="col-sm-6">
                        <div class="form-group">
                          <label>Rules Type</label>
                      <select class="form-control @error('network') is-invalid @enderror" id="frules" name="frules" disabled><!-- onchange="ShowHideDiv(this);" -->
                         <option value="" selected>-- Select Your Rule --</option>
                         <option id="IN-F" value="IN-F">InComing Traffic</option>
                         <option id="OUT-F" value="OUT-F">OutGoing Traffic</option>
                         <option id="FOR-F" value="FOR-F">Forword Traffic</option>
                         <option id="PRE-NAT" value="PRE-NAT">Pre Routing Using NAT Table</option>
                         <option id="POST-NAT" value="POST-NAT">Post Routing Using NAT Table</option>
                         <option id="IN-NAT" value="IN-NAT">Incoming Rule For NAT Table</option>
                         <option id="OUT-NAT" value="OUT-NAT">Outcoming Rule For NAT Table</option>
                      </select>                  
                       </div>
                   </div>
               </div>
               <div class="row">
                   <div class="col-sm-12">   
                       <div class="form-group" id="sin_interface">
                            <label>In Interface</label>
                            <select class="form-control @error('network') is-invalid @enderror" id="in_interface" name="in_interface">
                                <option value="" disabled selected>-- Select Interface --</option>
                            </select>                
                       </div>
                   </div>
                   <div class="col-sm-12">
                       <div class="form-group" id="sout_interface" style="display: none;">
                            <label>Out Interface</label>
                            <select class="form-control @error('network') is-invalid @enderror" id="out_interface" name="out_interface">
                                <option value="" disabled selected>-- Select Interface --</option>
                                @foreach($main_array as $roulelist)
                                <option value="{{ $roulelist['ip'] }}">{{ strtoupper($roulelist['ip']) }}</option>
                                @endforeach
                            </select>                
                       </div>
                   </div> 
                </div>
               <div class="row">
                   <div class="col-sm-12">            
                       <div class="form-group">
                            <label>Protocol</label>
                            <select class="form-control" id="protocol" name="protocol">
                                <option value="" selected>-- Select Protocol --</option>
                                <option value="tcp">TCP</option>
                                <option value="udp">UDP</option>
                                <option value="icmp">ICMP</option>    
                            </select>                
                       </div>
                   </div>
               </div>
                <div class="row">
                   <div class="col-sm-6">
                      <div class="form-group">
                         <label>Original Destination IP</label>
                         <select class="form-control" 
                            id="original_destination_iP" name="original_destination_iP">
                            <option value="" selected>-- Select Destination IP --</option>
                            <option value="Custom-IP" selected>Custom IP</option>
                            <option value="anywhere">AnyWhere</option>
                         </select>
                      </div>
                   </div>
                   <div class="col-sm-6">
                      <div class="form-group" id="odipdip">
                         <label class="original_dest_label">Destination IP</label>
                         <!-- <input type="text" class="form-control" id="cidestination_ip" name="cidestination_ip" placeholder="Enter Your Destination IP" value="{{ old('netmask_value') }}"> -->  
                         <input type="text" class="form-control" id="cidestination_ip" name="cidestination_ip" placeholder="Destination IP" value="">             
                      </div>
                      <!-- <div class="form-group" id="odianyip" style="display: none;">
                        <label>Anywhere IP</label>
                        <input type="text" class="form-control @error('odipanywhere_ip') is-invalid @enderror" id="odipanywhere_ip" name="odipanywhere_ip" value="0.0.0.0/0" readonly>                
                      </div> -->
                   </div>
                </div> 
                <!-- Original Destination Port -->
                <div class="row">
                   <!-- <div class="col-sm-6">
                        <div class="form-group">
                        <label>Original Destination Port</label>
                            <select class="form-control" 
                            id="original_destination_port" name="original_destination_port">
                                <option value="" selected>-- Select Destination Port --</option>
                                <option value="Custom-IP" selected>Custom Port</option>
                                <option value="anywhere">AnyWhere</option>
                            </select>                
                        </div>
                   </div> -->
                   <div class="col-sm-12">
                      <div class="form-group" id="odportdestip">
                         <label class="original_dest_port_label">Destination Port</label>
                         <input type="text" class="form-control" id="odpdestination_ip" name="odpdestination_ip" placeholder="Destination Port" value="">                
                      </div>
                      <!-- <div class="form-group" id="odportanyip" style="display: none;">
                        <label>Anywhere Port</label>
                        <input type="text" class="form-control @error('odanywhere_ip') is-invalid @enderror" id="odanywhere_ip" name="odanywhere_ip" value="0.0.0.0/0" readonly>                
                      </div> -->
                   </div>
                </div>
                <!-- ORIGINAL SOURCE IP -->
                <div class="row">
                   <div class="col-sm-6">
                        <div class="form-group">
                            <label>Original Source IP</label>
                            <select class="form-control" 
                            id="original_source_ip" name="original_source_ip">
                                <option value="">-- Select Source IP --</option>
                                <option value="Custom-IP" selected>Custom IP</option>
                                <option value="anywhere">AnyWhere</option>
                            </select>                
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group" id="osipdestip">
                             <label class="src_ip_label">Source IP</label>
                             <input type="text" class="form-control" id="osidestination_ip" name="osidestination_ip" placeholder="Source IP" value="">                
                        </div>
                    </div>
                </div>
                <!-- ORIGINAL SOURCE PORT -->
                <div class="row">
                   <!-- <div class="col-sm-6">
                        <div class="form-group">
                            <label>Original Source Port</label>
                            <select class="form-control" 
                            id="original_source_port" name="original_source_port">
                                <option value="" selected>-- Select Destination Port --</option>
                                <option value="Custom-IP">Custom Port</option>
                                <option value="anywhere">AnyWhere</option>
                            </select>                
                        </div>
                    </div> -->
                    <div class="col-sm-12">
                        <div class="form-group" id="osportdestip">
                             <label>Source Port</label>
                             <input type="text" class="form-control" id="osportsource_ip" name="osportsource_ip" placeholder="Source Port" value="">                
                        </div>
                    </div>
                </div>
                <div class="row rule_act">
                    <div class="col-sm-12">
                        <div class="form-group" id="rule_actionadr1">
                          <label>Rules Action</label>
                          <select class="form-control" id="layout_select" name="layout_select">
                             <option value="NULL">-- Select Your Action --</option>

                            <!-- For InComing Traffic(IN-F) -->
                             <option id="IN-F" value="ACCEPT">ACCEPT</option>
                             <option id="IN-F" value="DROP">DROP</option>
                             <option id="IN-F" value="REJECT">REJECT</option>

                            <!-- For OutGoing Traffic(OUT-F) -->
                             <option id="OUT-F" value="ACCEPT">ACCEPT</option>
                             <option id="OUT-F" value="DROP">DROP</option>
                             <option id="OUT-F" value="REJECT">REJECT</option>

                             <!-- For Forword Traffic(FOR-F) -->
                             <option id="FOR-F" value="ACCEPT">ACCEPT</option>
                             <option id="FOR-F" value="DROP">DROP</option>
                             <option id="FOR-F" value="REJECT">REJECT</option>

                             <!-- Incoming Rule For NAT Table(IN-NAT) -->
                             <option id="IN-NAT" value="ACCEPT">ACCEPT</option>  
                             <option id="IN-NAT" value="SNAT">SNAT</option>
                             <option id="IN-NAT" value="NULL">NULL</option>

                            <!-- Outcoming Rule For NAT Table(OUT-NAT) -->
                              <option id="OUT-NAT" value="DNAT">DNAT</option>
                             <option id="OUT-NAT" value="NULL">NULL</option>
                             <!-- <option id="OUT-NAT" value="REDIRECT">REDIRECT</option> -->

                          </select>                  
                        </div>

                        <div class="form-group" id="rule_accept" style="display: none;">
                          <label>Rules Action</label>
                          <select class="form-control" id="rule_actionaccept" name="rule_actionaccept">
                             <option value="NULL">-- Select Your Action --</option>
                             <option value="ACCEPT">ACCEPT</option>                       
                          </select> 
                        </div>

                    </div>
                </div>
                <div class="row destination">
                    <div class="col-sm-6">
                        <label>Translated Destination</label>
                          <select class="form-control" id="t_dest_type" name="t_dest_type">
                             <option value="default">-- Select Destination --</option>
                             <option value="dnat">DNAT</option>    
                             <option value="NULL">NULL</option>
                             <!-- <option value="dnat_redirect">Redirect</option>                    -->
                          </select>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group dnat_address">
                             <label>Destination IP</label>
                             <input readonly type="text" class="form-control" id="trans_desti_add" name="trans_desti_add" placeholder="Translated Destination IP">
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group dnat_redirect_port">
                             <label>Destination Port</label>
                             <input readonly type="text" class="form-control" id="trans_desti_port" name="trans_desti_port" placeholder="Translated Destination Port">       
                        </div>
                    </div>
                </div>
                <div class="row source">
                    <div class="col-sm-6">
                        <label>Translated Source</label>
                          <select class="form-control" id="t_source_type" name="t_source_type">
                             <option value="default">-- Select Source --</option>
                             <option value="snat">SNAT</option>    
                             <!-- <option value="snat_redirect">Redirect</option>                    -->
                          </select>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group snat_address">
                             <label>Translated Source Address</label>
                             <input readonly type="text" class="form-control" id="trans_source_add" name="trans_source_add" placeholder="Translated Source Address">                
                        </div>
                        <div class="form-group snat_redirect_port" style="display: none;">
                             <label>Translated Source Port</label>
                             <input readonly type="text" class="form-control" id="trans_source_port" name="trans_source_port" placeholder="Translated Source Port">                
                        </div>
                    </div>
                </div>
                <div class="row red1">
                    <!-- <div class="col-sm-6">
                      <div class="form-group">
                         <label>Redirect</label>
                         <select class="form-control" 
                            id="redirect_port" name="redirect_port">
                            <option value="" selected>-- Select Redirect Port --</option>
                            <option value="yes">Yes</option>
                            <option value="yes_with_port">Yes With Port</option>
                         </select>
                      </div>
                    </div> -->
                    <!-- <div class="col-sm-6">
                      <div class="form-group" id="odipdip">
                         <label class="yes_with_port_label">Yes With Port</label>
                         <input type="text" class="form-control" id="yes_w_port" name="yes_w_port" placeholder="Yes With Port" value="">             
                      </div>
                    </div> -->
                    <div class="col-sm-12">
                        <div class="form-group">
                          <label>Redirect</label>
                          <input type="text" class="form-control" id="redirect_port" name="redirect_port" placeholder="Redirect Port">                 
                        </div>
                    </div>
                </div>
               <!--  <div class="row redmas">
                    <div class="col-sm-12">
                        <div class="form-group">
                          <label>Masquerade</label>
                          <input type="text" class="form-control" id="masquerade_port" name="masquerade_port" placeholder="Masquerade Port">                  
                        </div>
                    </div>
                </div> -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                          <label>Add/ Delete</label>
                          <select class="form-control" id="add_delete" name="add_delete"> 
                            <option value="" selected>-- Select Add/Delete --</option>  
                            <option value="ADD">ADD</option>
                            <option value="DELETE">DELETE</option>
                          </select>                  
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
               <button type="submit" id="dsubmit" class="btn btn-primary btn-sm" disabled>Submit</button>
               <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Cancel</button>
            </div>
         </form>
      </div>
   </div>
</div>
@endsection