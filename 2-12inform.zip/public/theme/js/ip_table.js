$(document).ready(function(){  
    $(".destination, .source, .red1, .redmas").hide();
    $("#frules").on("change",function(){
        if (this.value == "IN-F") {

            $("#sin_interface, .rule_act, #rule_actionadr").show();

            $("#sout_interface, .destination, .source, .red1, .redmas").hide();

        }else if (this.value == "OUT-F") {

            $("#sout_interface, .rule_act, #rule_actionadr").show();

            $("#sin_interface, .destination, .source, .red1, .redmas").hide();

        }else if (this.value == "PRE-NAT") {

            $("#sin_interface, .destination, .red1").show();

            $("#sout_interface, .rule_act, .source, .redmas").hide();

        } else if (this.value == "POST-NAT") {

            $("#sin_interface, .rule_act, .destination, .red1").hide();

            $("#sout_interface, .source, .redmas").show();

        }else if(this.value == "FOR-F"){

            $("#sin_interface, #sout_interface, .rule_act, #rule_actionadr").show();

            $(".destination, .source, .red1, .redmas").hide();

        }else if(this.value == "IN-NAT"){

            $("#sin_interface, .rule_act").show();

            $(".destination, .source, .red1, .redmas, #sout_interface, #rule_actionadr").hide();

        }else if(this.value == "OUT-NAT"){

            $("#sout_interface, .rule_act").show();

            $("#sin_interface, .destination, .source, .red1, .redmas, #rule_actionadr").hide();

        }

        if (this.value == "IN-NAT") {
            $("#in_net_rule_accept").show();
        } else {
            $("#in_net_rule_accept").hide();
        }

        if (this.value == "OUT-NAT") {
            $("#out_net_rule_accept").show();
        } else {
            $("#out_net_rule_accept").hide();
        }
    });

    $("#original_destination_iP").on("change",function(){
        if (this.value == "Custom-IP") {
            $("#cidestination_ip").attr("readonly",false);
            $(".original_dest_label").text("Destination IP");
            $("#cidestination_ip").attr("placeholder","Destination IP");
            $("#cidestination_ip").val('');
        } else {
            $(".original_dest_label").text("Anywhere IP");
            $("#cidestination_ip").attr("placeholder","");
            $("#cidestination_ip").val('0.0.0.0/0');
            $("#cidestination_ip").attr("readonly",true);
        } 
    });
    // Original Destination Port
    // $("#original_destination_port").on("change",function(){
    //     if (this.value == "Custom-IP") {
    //         $("#odpdestination_ip").attr("readonly",false);
    //         $(".original_dest_port_label").text("Destination IP");
    //         $("#odpdestination_ip").attr("placeholder","Destination Port");
    //         $("#odpdestination_ip").val('');
    //     } else {
    //         $(".original_dest_port_label").text("Anywhere IP");
    //         $("#odpdestination_ip").attr("placeholder","");
    //         $("#odpdestination_ip").val('0.0.0.0/0');
    //         $("#odpdestination_ip").attr("readonly",true);
    //     } 
    // });
    // ORIGINAL SOURCE IP
    $("#original_source_ip").on("change",function(){
        if (this.value == "Custom-IP") {
            $("#cidestination_ip").attr("readonly",false);
            $(".src_ip_label").text("Source IP");
            $("#osidestination_ip").attr("placeholder","Source IP");
            $("#osidestination_ip").val('');
        } else {
            $(".src_ip_label").text("Anywhere IP");
            $("#osidestination_ip").attr("placeholder","");
            $("#osidestination_ip").val('0.0.0.0/0');
            $("#osidestination_ip").attr("readonly",true);
        } 
    });
    $("#protocol").on("change",function(){
        if (this.value == "icmp") {
            $("#odpdestination_ip").attr("disabled",true);
            $("#osportsource_ip").attr("disabled",true);
        }else {
            $("#odpdestination_ip").attr("disabled",false);
            $("#osportsource_ip").attr("disabled",false);
        }
    });
    $("#t_dest_type").on("change",function(){
        if (this.value == "default") {
            $("#trans_desti_add, #trans_desti_port").attr("readonly",true);
            $(".dnat_address, .dnat_redirect_port").show();
            
        }else if (this.value == "dnat") {
            $(".dnat_address, .dnat_redirect_port").show();
            $("#trans_desti_add, #trans_desti_port").attr("readonly",false);
            $("#trans_desti_port")[0].reset();
        }else if (this.value == "dnat_redirect") {
            $(".dnat_address").hide();
            $(".dnat_redirect_port").show();
            $("#trans_desti_port").attr("readonly",true);
            $("#trans_desti_port").val('0.0.0.0/0');
        }else{
            $(".dnat_address").show();
            $(".dnat_redirect_port").hide();            
        }
    });
    $("#t_source_type").on("change",function(){        
        if (this.value == "default") {
           $("#trans_source_add, #trans_source_port").attr("readonly",true);            
        }else if (this.value == "snat") {
          //  console.log(this.value);
            $(".snat_address").show();
            $(".snat_redirect_port").hide();
        }else if (this.value == "snat_redirect") {
         //   console.log(this.value);
            $(".snat_address").hide();
            $(".snat_redirect_port").show();
        }else{
            $(".snat_address").show();
            $(".snat_redirect_port").hide();
        }
    });
    $("#device_serial_number").on("change",function(){
        if (this.value == "") {
            $("#frules").attr("disabled",true);
            $("#fiptables")[0].reset();
            $("#dsubmit").attr("disabled",true);
        }else {
            $("#frules").attr("disabled",false);
        }
    });
    $("#frules").on("change",function(){
        if (this.value == "") {
            $("#dsubmit").attr("disabled",true);
        }else {
            $("#dsubmit").attr("disabled",false);
        }
    });

    $(document).ready(function() {
    $("#layout_select").children('option:gt(0)').hide();
    $("#frules").change(function() {
        $("#layout_select").children('option').hide();
        $("#layout_select").children("option[id^=" + $(this).val() + "]").show()
        })
    })

   //  $('#device_serial_number').on('change',function(){
   //      var dev_num = $(this).val();    
   //      alert(dev_num);
   //      if(dev_num){
   //          $.ajax({
   //             type:"GET",
   //             url:"{{url('ip-info/ajaxinterface')}}?device_serial="+dev_num,
   //             success:function(res){               
   //              if(res){
   //                  $("#in_interface").empty();
   //                  $.each(res,function(key,value){
   //                      $("#in_interface").append('<option value="'+key+'">'+value+'</option>');
   //                  });
               
   //              }else{
   //                 $("#in_interface").empty();
   //              }
   //             }
   //          });
   //      }else{
   //          $("#in_interface").empty();
   //      }
        
   // });

});