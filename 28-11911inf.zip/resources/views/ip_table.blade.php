@extends('layouts.app')
@section('content')
<div class="main-content">
   <div class="section__content section__content--p30">
      <div class="container-fluid">
         <div class="row m-t-30">
            <div class="col-lg-12">
               <h3 class="title-5 m-b-35">IP Table</h3>
               <div class="table-responsive m-b-40">
                  <div class="table-title">
                     <div class="row">
                        <div class="col-sm-6">
                           <!-- <form class="form-inline my-2 my-lg-0" action="{{url('route-list')}}" method="GET">
                              <input class="form-control" type="search" name="q" placeholder="Device Serial Number"> &nbsp;
                              <button type="submit" class="btn btn-primary">Search</button>
                           </form> -->
                           <br> 
                        </div>
                        <div class="col-sm-3">
                        </div>
                        <div class="col-sm-3">
                           <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="fa fa-plus"></i> <span>Add New Rule</span></a>  
                           <!-- <a href="javascript:void(0)" class="btn btn-success" id="new-customer" data-toggle="modal"><i class="fa fa-plus"></i> <span>Add New Route</span></a> -->
                        </div>
                     </div>
                  </div>
                  <br>
                  <table class="table table-borderless table-data3">
                     <thead>
                        <tr>
                           <th>Device Serial Number</th>
                           <th>Chain Type</th>
                           <th>Pakets</th>
                           <th>Bytes</th>
                           <th>Target</th>
                           <th>Protocol</th>
                           <th>In Interface</th>
                           <th>Out Interface</th>
                           <th>Source Address</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                           <td>Demo</td>
                        </tr>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Add Moduel -->
                <div id="addEmployeeModal" class="modal fade">
   <div class="modal-dialog">
      <div class="modal-content">
         <form action ="{{url('route-opertion/store')}}" method="POST">
            {!! csrf_field() !!}
            <div class="modal-header">
               <h4 class="modal-title">Add New Rule</h4>
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body">
        
                <div class="form-group">
                  <label>Rules Type</label>
                  <select class="form-control @error('network') is-invalid @enderror" id="frules" name="frules" onchange="ShowHideDiv(this);">
                     <option value="" disabled selected>-- Select Your Rule --</option>
                     <option value="IN-F">InComing Traffic</option>
                     <option value="OUT-F">OutGoing Traffic</option>
                     <option value="FOR-F">Forword Traffic</option>
                     <option value="PRE-NAT">Pre Routing Using Net Table</option>
                     <option value="POST-NAT">Post Routing Using Net Table</option>
                     <option value="IN-NAT">Incoming Rule For Net Table</option>
                     <option value="OUT-NAT">Outcoming Rule For Net Table</option>
                  </select>                  
               </div>   
               <div class="form-group" id="sin_interface" style="display: none;">
                    <label>In Interface</label>
                    <select class="form-control @error('network') is-invalid @enderror" id="in_interface" name="in_interface">
                        <option value="" disabled selected>-- Select Interface --</option>
                        <option value="LTE">LTE</option>
                        <option value="WAN">WAN</option>
                        <option value="LAN">LAN</option>
                    </select>                
               </div> 
               <div class="form-group" id="sout_interface" style="display: none;">
                    <label>Out Interface</label>
                    <select class="form-control @error('network') is-invalid @enderror" id="out_interface" name="out_interface">
                        <option value="" disabled selected>-- Select Interface --</option>
                        <option value="LTE">LTE</option>
                        <option value="WAN">WAN</option>
                        <option value="LAN">LAN</option>
                    </select>                
               </div>             
               <div class="form-group">
                    <label>Protocol</label>
                    <select class="form-control" id="protocol" name="protocol" onchange="PROTOCOL(this);">
                        <option value="" disabled selected>-- Select Protocol --</option>
                        <option value="TCP">TCP</option>
                        <option value="UDP">UDP</option>
                        <option value="ICMP">ICMP</option>    
                    </select>                
               </div>
                <div class="row">
                   <div class="col-sm-6">
                      <div class="form-group">
                         <label>Original Destination IP</label>
                         <select class="form-control" 
                            id="original_destination_iP" onchange="ODIP(this);" name="original_destination_iP">
                            <option value="" selected>-- Select Destination IP --</option>
                            <option value="Custom-IP">Custom IP</option>
                            <option value="anywhere">AnyWhere</option>
                         </select>
                      </div>
                   </div>
                   <div class="col-sm-6">
                      <div class="form-group" id="odipdip" style="display: none;">
                         <label>Destination IP</label>
                         <input type="text" class="form-control" id="cidestination_ip" name="cidestination_ip" placeholder="Enter Your Destination IP" value="{{ old('netmask_value') }}">                
                      </div>
                      <div class="form-group" id="odianyip" style="display: none;">
                        <label>Anywhere IP</label>
                        <input type="text" class="form-control @error('odipanywhere_ip') is-invalid @enderror" id="odipanywhere_ip" name="odipanywhere_ip" value="0.0.0.0/0" readonly>                
                      </div>
                   </div>
                </div> 
                <!-- Original Destination Port -->
                <div class="row">
                   <div class="col-sm-6">
                        <div class="form-group">
                        <label>Original Destination Port</label>
                            <select class="form-control" 
                            id="original_destination_port" onchange="ODPORT(this);" name="original_destination_port">
                                <option value="" selected>-- Select Destination Port --</option>
                                <option value="Custom-IP">Custom Port</option>
                                <option value="anywhere">AnyWhere</option>
                            </select>                
                        </div>
                   </div>
                   <div class="col-sm-6">
                    <div class="form-group" id="odportdestip" style="display: none;">
                         <label>Destination Port</label>
                         <input type="text" class="form-control @error('odpdestination_ip') is-invalid @enderror" id="odpdestination_ip" name="odpdestination_ip" placeholder="Destination Port" value="{{ old('odpdestination_ip') }}">                
                      </div>
                      <div class="form-group" id="odportanyip" style="display: none;">
                        <label>Anywhere Port</label>
                        <input type="text" class="form-control @error('odanywhere_ip') is-invalid @enderror" id="odanywhere_ip" name="odanywhere_ip" value="0.0.0.0/0" readonly>                
                      </div>
                   </div>
                </div>
                <!-- ORIGINAL SOURCE IP -->
                <div class="row">
                   <div class="col-sm-6">
                        <div class="form-group">
                            <label>Original Source IP</label>
                            <select class="form-control" 
                            id="original_source_ip" onchange="OSIP(this);" name="original_source_ip">
                                <option value="" selected>-- Select Destination Port --</option>
                                <option value="Custom-IP">Custom IP</option>
                                <option value="anywhere">AnyWhere</option>
                            </select>                
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group" id="osipdestip" style="display: none;">
                             <label>Source IP</label>
                             <input type="text" class="form-control" id="osidestination_ip" name="osidestination_ip" placeholder="Source IP" value="{{ old('osidestination_ip') }}">                
                        </div>
                        <div class="form-group" id="osipanyip" style="display: none;">
                            <label>Anywhere IP</label>
                            <input type="text" class="form-control" id="osipanywhere_ip" name="osipanywhere_ip" value="0.0.0.0/0" readonly>              
                      </div>
                    </div>
                </div>
                <!-- ORIGINAL SOURCE PORT -->
                <div class="row">
                   <div class="col-sm-6">
                        <div class="form-group">
                            <label>Original Source Port</label>
                            <select class="form-control" 
                            id="original_source_port" onchange="OSPORT(this);" name="original_source_port">
                                <option value="" selected>-- Select Destination Port --</option>
                                <option value="Custom-IP">Custom Port</option>
                                <option value="anywhere">AnyWhere</option>
                            </select>                
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group" id="osportdestip" style="display: none;">
                             <label>Source Port</label>
                             <input type="text" class="form-control" id="osportsource_ip" name="osportsource_ip" placeholder="Source Port" value="{{ old('osidestination_ip') }}">                
                        </div>
                        <div class="form-group" id="osportanyip" style="display: none;">
                            <label>Anywhere Port</label>
                            <input type="text" class="form-control" id="osportanywhere_ip" name="osportanywhere_ip" value="0.0.0.0/0" readonly>              
                      </div>
                    </div>
                </div>
                    <div class="form-group" id="rule_actionadr" style="display: none;">
                      <label>Rules Action</label>
                      <select class="form-control" id="rule_action1" name="rule_action1">
                         <option value="NULL">-- Select Your Action --</option>
                         <option value="ACCEPT">ACCEPT</option>
                         <option value="DROP">DROP</option>
                         <option value="REJECT">REJECT</option>                         
                      </select>                  
                    </div>
                    <div class="form-group" id="rule_accept" style="display: none;">
                      <label>Rules Action</label>
                      <select class="form-control" id="rule_actionaccept" name="rule_actionaccept">   
                        <option value="ACCEPT" selected>ACCEPT</option>
                      </select>                  
                    </div>

                    <div class="form-group">
                         <label>Translated Destination Address</label>
                         <input type="text" class="form-control" id="trans_desti_add" name="trans_desti_add" placeholder="Translated Destination Address">                
                    </div>

                    <div class="form-group">
                         <label>Translated Source Address</label>
                         <input type="text" class="form-control" id="trans_sorce_add" name="trans_sorce_add" placeholder="Translated Source Address">                
                    </div>

                    <div class="form-group">
                         <label>Redirect Port</label>
                         <input type="text" class="form-control" id="cidestination_ip" name="cidestination_ip" placeholder="Enter Your Destination IP">                
                    </div>

                    <div class="form-group" >
                         <label>Masquerade Port</label>
                         <input type="text" class="form-control" id="cidestination_ip" name="cidestination_ip" placeholder="Enter Your Destination IP">                
                    </div>

                    <!-- Add Delete -->
                    <div class="form-group">
                      <label>Add/ Delete</label>
                      <select class="form-control" id="add_delete" name="add_delete"> 
                        <option value="" disabled selected>-- Select Add/Delete --</option>  
                        <option value="ADD">ADD</option>
                        <option value="DELETE">DELETE</option>
                      </select>                  
                    </div>
                             



               


               



            </div>
            <div class="modal-footer">
               <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">         
               <button type="submit" class="btn btn-primary btn-sm">Submit</button>
            </div>
         </form>
      </div>
   </div>
</div>
<script type="text/javascript">
        function ShowHideDiv(that) {
    if (that.value == "IN-F" || that.value == "FOR-F" || that.value == "PRE-NAT" || that.value == "IN-NAT") {
        document.getElementById("sin_interface").style.display = "block";
    } else {
        document.getElementById("sin_interface").style.display = "none";
    }

    if (that.value == "OUT-F" || that.value == "FOR-F" || that.value == "POST-NAT" || that.value == "OUT-NAT") {
        document.getElementById("sout_interface").style.display = "block";
    } else {
        document.getElementById("sout_interface").style.display = "none";
    }

    if (that.value == "PRE-NAT" || that.value == "POST-NAT") {
        document.getElementById("rule_actionadr").style.display = "none";
    } else {
        document.getElementById("rule_actionadr").style.display = "block";
    }

    if (that.value == "IN-NAT" || that.value == "OUT-NAT") {
        document.getElementById("rule_accept").style.display = "block";
    } else {
        document.getElementById("rule_accept").style.display = "none";
    }
}

function ODIP(that) {
    if (that.value == "Custom-IP") {
        document.getElementById("odipdip").style.display = "block";
    } else {
        document.getElementById("odipdip").style.display = "none";
    } 

    if (that.value == "anywhere") {
        document.getElementById("odianyip").style.display = "block";
    } else {
        document.getElementById("odianyip").style.display = "none";
    }  
}
// Original Destination Port
function ODPORT(that) {
    if (that.value == "Custom-IP") {
        document.getElementById("odportdestip").style.display = "block";
    } else {
        document.getElementById("odportdestip").style.display = "none";
    } 

    if (that.value == "anywhere") {
        document.getElementById("odportanyip").style.display = "block";
    } else {
        document.getElementById("odportanyip").style.display = "none";
    }  
}
// ORIGINAL SOURCE IP
function OSIP(that) {
    if (that.value == "Custom-IP") {
        document.getElementById("osipdestip").style.display = "block";
    } else {
        document.getElementById("osipdestip").style.display = "none";
    } 

    if (that.value == "anywhere") {
        document.getElementById("osipanyip").style.display = "block";
    } else {
        document.getElementById("osipanyip").style.display = "none";
    }  
}

// ORIGINAL SOURCE PORT
function OSPORT(that) {
    if (that.value == "Custom-IP") {
        document.getElementById("osportdestip").style.display = "block";
    } else {
        document.getElementById("osportdestip").style.display = "none";
    } 

    if (that.value == "anywhere") {
        document.getElementById("osportanyip").style.display = "block";
    } else {
        document.getElementById("osportanyip").style.display = "none";
    }  
}


</script>
@endsection