<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\RouteOperation;
use App\Connection;
use DB;
use App\DeviceInfo;

class InterFaceController extends Controller
{
    public function index(Request $request)
    {	
      $interfaceinfo = DeviceInfo::all();

     // $q = $request->get('q'); 
      //$searchdeviceinfo = DeviceInfo::where( 'device_serial', 'LIKE', '%' . $q . '%' )->get();
      //$searchdeviceinfo = DB::table('tbl_device_info')->where("device_serial","LIKE", "%" . $q . "%")
      //->get();
      $main_array = [];
      foreach( $interfaceinfo as $interfaceinf){
        $interface_with_ip =  $interfaceinf->interface_with_ip;           
        if($interface_with_ip !== ""){
          $interface_with_ip1 = explode(',', $interface_with_ip);
          foreach($interface_with_ip1 as $interface_with_ip2){
            $interface_with_ip3 = explode('::',$interface_with_ip2);
             $a = array(
              'device_serial'=>  $interfaceinf->device_serial,
              'ip'  =>  $interface_with_ip3[0],
              'interface' => $interface_with_ip3[1]
             );
           $main_array [] =  $a;
          }
        }
      }
      return view('interface_details', compact('main_array')); 
	}

}